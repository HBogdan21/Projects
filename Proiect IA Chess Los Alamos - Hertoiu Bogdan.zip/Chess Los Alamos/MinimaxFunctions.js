var maxDepth = 3;


function minFun(board, depth) {
  if (depth >= maxDepth) {
    board.setScore();
    return board.score;
  }

  var boards = board.generateNewBoardsWhitesTurn();
  var lowestBoardNo = 0;
  var lowestScore = 100000;
  for (var i = 0; i < boards.length; i++) {
    if (!boards[i].isDead()) {
      var score = maxFun(boards[i], depth + 1);
      if (score < lowestScore) {
        lowestBoardNo = i;
        lowestScore = score;
      }
    }
  }
  return lowestScore;
}

function maxFun(board, depth) {
  if (depth >= maxDepth) {
    board.setScore();
    return board.score;
  }


  var boards = board.generateNewBoardsBlacksTurn();
  if (depth == 0) {
    
  }
  var topBoardNo = 0;
  var topScore = -100000;
  for (var i = 0; i < boards.length; i++) {
    var score = minFun(boards[i], depth + 1);
    if (score > topScore) {
      topBoardNo = i;
      topScore = score;
    }
  }

  if (depth == 0) {
    
    return boards[topBoardNo];
  }
  return topScore;
}
