import cv2
import cv2 as cv
from matplotlib import pyplot as plt
import numpy as np
from sklearn.cluster import KMeans
import pandas as pd
import os
import argparse
import imutils

def recalculateBlackPixels(inputImgObjects):
	tmp2 = np.sum(inputImgObjects, axis=2)
	tmp2[tmp2<100] = 0
	bounds = np.where(tmp2==0)
	left, right, top, down = np.min(bounds[0]), np.max(bounds[1]), np.min(bounds[1]), np.max(bounds[0])
	if right>down:
		imgObject = inputImgObjects[left:right+1, top:down+1]
	else:
		imgObject = inputImgObjects[top:down + 1, left:right+1]
	height, width, channels = imgObject.shape
	blackPixelCountLeftSide = 0
	blackPixelCountRightSide = 0
	blackPixelCountUpperSection = 0
	blackPixelCountBottomSection = 0
	for column in range(0, height):
		if imgObject[column][width // 2][0] < 10:
			if column < height // 2:
				blackPixelCountLeftSide += 1
			else:
				blackPixelCountRightSide += 1

	for row in range(0, width):
		if imgObject[height // 2][row][0] < 10:
			if row < width // 2:
				blackPixelCountUpperSection += 1
			else:
				blackPixelCountBottomSection += 1
	sumdiff = np.abs(blackPixelCountLeftSide - blackPixelCountRightSide) + \
		np.abs(blackPixelCountUpperSection - blackPixelCountBottomSection)
	return sumdiff


def blackPixelsDistribution(normalizedImg, objID):
	height, width, channels = normalizedImg.shape
	blackPixelsRows = np.zeros(height)
	blackPixelsColumns = np.zeros(width)
	for row in range(0, width):
		blackPixelsCount = 0
		for column in range(0, height):
			if normalizedImg[row][column][0] < 10:
				blackPixelsCount += 1
		blackPixelsRows[row] = blackPixelsCount

	for column in range(0, height):
		blackPixelsCount = 0
		for row in range(0, width):
			if normalizedImg[row][column][0] < 10:
				blackPixelsCount += 1
		blackPixelsColumns[column] = blackPixelsCount

	blackPixelsRows = processingDistribution_1(blackPixelsRows)
	blackPixelsColumns = processingDistribution_1(blackPixelsColumns)

	df = pd.DataFrame(data={'pixelRow': blackPixelsRows, 'pixelColumn': blackPixelsColumns})
	df.to_csv('PixelsDistribution\distPictures{}.csv'.format(objID), sep=";", index=False)

def processingDistribution_1(blackPixels):
	"""
	Smoothing values for the black pixels by calculating average of 3 values inside the array of black pixels
	:return:
	"""
	average = 0
	result = blackPixels
	average = (blackPixels[0] + blackPixels[1]) / 2
	result[0] = average
	for index in range(1, len(blackPixels) - 1):

		average = ( blackPixels[index - 1] + blackPixels[index] + blackPixels[index + 1] ) / 3
		result[index] = average

	result[-1] = (blackPixels[-1] + blackPixels[-2]) / 2

	return result

image_number = 0
inputDirectory = os.listdir('InputPictures')
for img in range(0, len(inputDirectory)):
	print(inputDirectory[img])

	image = cv.imread("InputPictures\\" + inputDirectory[img])
	original = image.copy()

	gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
	blur = cv.GaussianBlur(gray, (5,5), 0)
	thresh = cv.threshold(blur, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU)[1]
	kernel = cv.getStructuringElement(cv.MORPH_RECT, (3,3))
	dilate = cv.dilate(thresh, kernel, iterations=1) # 3

	dilate_copy = cv.bitwise_not(dilate)

	cnts = cv.findContours(dilate_copy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
	cnts = cnts[0] if len(cnts) == 2 else cnts[1]

	for c in cnts:
		x,y,w,h = cv.boundingRect(c)

		crop_img = thresh[y:y + h, x:x + w]
		height, width = crop_img.shape
		if height > 45 and width > 45:
			cv.imwrite("CroppedPictures\cropped{}.jpg".format(image_number), crop_img)
			cv.rectangle(image, (x, y), (x + w, y + h), (36,255,12), 2)
			ROI = original[y:y+h, x:x+w]
			image_number += 1

blackPixelCountLeftSide = 0
blackPixelCountRightSide = 0
blackPixelCountUpperSection = 0
blackPixelCountBottomSection = 0
for image_index in range(0, image_number):
	inputImgObjects = cv.imread("CroppedPictures\cropped{}.jpg".format(image_index))
	height, width, channels = inputImgObjects.shape
	blackPixelCountLeftSide = 0
	blackPixelCountRightSide = 0
	blackPixelCountUpperSection = 0
	blackPixelCountBottomSection = 0
	for column in range(0, height):
		if inputImgObjects[column][width//2][0] < 10:
			if column < height // 2:
				blackPixelCountLeftSide += 1
			else:
				blackPixelCountRightSide += 1

	for row in range(0, width):
		if inputImgObjects[height//2][row][0] < 10:
			if row < width // 2:
				blackPixelCountUpperSection += 1
			else:
				blackPixelCountBottomSection += 1

	rotated = inputImgObjects
	height, width, _ = rotated.shape

	background_height = max(height, width)
	background_width = max(height, width)
	background_color = (255, 255, 255)
	# Create the background
	background = np.zeros((background_height, background_width, 3), dtype=np.uint8)
	background.fill(background_color[0])
	# Paste the rotated image onto the background
	x = (background_width - width) // 2
	y = (background_height - height) // 2
	background[y:y + height, x:x + width] = rotated

	rotated = background
	minPixels = recalculateBlackPixels(rotated)
	bestRotation = 0
	for angle in np.arange(15, 360, 15):  # rotate left

		center = (rotated.shape[1] // 2, rotated.shape[0] // 2)
		rot_mat = cv2.getRotationMatrix2D(center, angle, 1)
		rotated = cv2.warpAffine(inputImgObjects, rot_mat, (background_height, background_width), borderValue=(255, 255, 255))
		curPixels = recalculateBlackPixels(rotated)
		if curPixels < minPixels:
			minPixels = curPixels
			bestRotation = angle
		else:
			break
	if bestRotation == 0:
		for angle in np.arange(-15, -360, -15):  # rotate right
			center = (rotated.shape[1] // 2, rotated.shape[0] // 2)
			rot_mat = cv2.getRotationMatrix2D(center, angle, 1)
			rotated = cv2.warpAffine(inputImgObjects, rot_mat, (background_height, background_width), borderValue=(255, 255, 255))
			curPixels = recalculateBlackPixels(rotated)
			if curPixels <= minPixels:
				minPixels = curPixels
				bestRotation = angle
			else:
				break

	center = (background.shape[1] // 2, background.shape[0] // 2)
	rot_mat = cv2.getRotationMatrix2D(center, bestRotation, 1)
	height, width, _ = background.shape

	# Calculate the dimensions of the background
	background_height = max(height, width)
	background_width = max(height, width)
	bestimg = cv2.warpAffine(background, rot_mat, (background_height, background_width), borderValue=(255, 255, 255))
	cv.imwrite("RotatedPictures\\rotated{}.jpg".format(image_index), bestimg)
	print("best angle: ", bestRotation)
listOfNormImages = []
for image_index in range(0, image_number):
	normalize_rotatedImg = cv.imread("RotatedPictures\\rotated{}.jpg".format(image_index))
	normalize_rotatedImg = cv.resize(normalize_rotatedImg, (64, 64))
	listOfNormImages.append(normalize_rotatedImg)
	cv.imwrite("NormalizedPictures\\normalized{}.jpg".format(image_index), normalize_rotatedImg)
	blackPixelsDistribution(listOfNormImages[image_index], image_index)
