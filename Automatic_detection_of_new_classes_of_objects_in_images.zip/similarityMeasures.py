import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import scipy.spatial.distance as dist
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from sklearn.cluster import AgglomerativeClustering
import cv2 as cv

files = os.listdir('PixelsDistribution')
folderSize = len(os.listdir('PixelsDistribution'))
print (files)
df = None
for file in files:
    tmp = pd.read_csv('PixelsDistribution\\' + file, sep=';')
    cols = tmp.columns
    cols = {x+'_'+file.split('.')[0][12:] for x in cols}
    tmp = tmp.rename(columns={'pixelRow': list(cols)[1], 'pixelColumn': list(cols)[0]})
    if df is None:
        df = tmp.copy()
    else:
        df[tmp.columns] = tmp.values

distanceMatrix = np.zeros((df.shape[1]//2, df.shape[1]//2))
for i in range(0, df.shape[1]//2):
    for j in range(0, df.shape[1]//2):
        s1 = np.abs((df[f'pixelRow_{i}'] - df[f'pixelRow_{j}']).sum())
        s2 = np.abs((df[f'pixelColumn_{i}'] - df[f'pixelColumn_{j}']).sum())
        distanceMatrix[i,j] = s1+s2
print('ttttt')

def hierarchicalClustering(distanceMatrix, minObjinCluster, maxObjinCluster, distanceThreshold):
    df = pd.DataFrame(data=distanceMatrix)
    numberObjects = len(distanceMatrix)
    for currentNumberOfObjects in range(minObjinCluster, numberObjects):
        if currentNumberOfObjects > df.shape[0]:
            break

        condensed_distance_matrix = df.iloc[:currentNumberOfObjects, :currentNumberOfObjects].values
        Z = linkage(condensed_distance_matrix, method='single',
                    metric='euclidean')
        objectMembership = fcluster(Z, t=distanceThreshold, criterion='distance')
        clusterIDs = np.unique(objectMembership)
        for ID in range(0, len(clusterIDs)):
            object_indices = np.where(objectMembership == clusterIDs[ID])[0]  # objects that belong to cluster
            cluster_size = len(object_indices)
            if cluster_size >= minObjinCluster:
                # column = nr object
                # value itself from array = cluster ID

                randomImg = np.random.choice(object_indices,3,replace=False)

                imagePath = "NormalizedPictures\\normalized{}.jpg".format(df.columns[randomImg[0]]) #Df columns is name of the image, randomImg offers position of image

                img1 = cv.imread(imagePath)

                imagePath = "NormalizedPictures\\normalized{}.jpg".format(df.columns[randomImg[1]])
                img2 = cv.imread(imagePath)

                imageDisplay = np.concatenate((img1, img2), axis=1)
                cv.imshow('Image Comparison', imageDisplay)
                cv.waitKey(0)
                cv.destroyAllWindows()


                inputChoice = None
                while True:
                    print("Are the images that were shown the same? (y/n)")
                    inputChoice = input()
                    if inputChoice == 'y':
                        break
                    if inputChoice == 'n':
                        imagePath = "NormalizedPictures\\normalized{}.jpg".format(df.columns[randomImg[0]])
                        img1 = cv.imread(imagePath)

                        imagePath = "NormalizedPictures\\normalized{}.jpg".format(df.columns[randomImg[2]])
                        img2 = cv.imread(imagePath)

                        imageDisplay = np.concatenate((img1, img2), axis=1)
                        cv.imshow('Image Comparison', imageDisplay)
                        cv.waitKey(0)
                        cv.destroyAllWindows()
                        print("Case 1: Are the images that were shown the same? (y/n)")
                        inputChoice = input()
                        if inputChoice == 'y':
                            df = df.loc[df.index != df.columns[randomImg[1]]]  # row
                            del df[df.columns[randomImg[1]]] # column
                            distanceMatrix = df.values
                            break

                        imagePath = "NormalizedPictures\\normalized{}.jpg".format(df.columns[randomImg[1]])
                        img1 = cv.imread(imagePath)

                        imagePath = "NormalizedPictures\\normalized{}.jpg".format(df.columns[randomImg[2]])
                        img2 = cv.imread(imagePath)

                        imageDisplay = np.concatenate((img1, img2), axis=1)
                        cv.imshow('Image Comparison', imageDisplay)
                        cv.waitKey(0)
                        cv.destroyAllWindows()
                        print("Case 2: Are the images that were shown the same? (y/n)")
                        inputChoice = input()
                        if inputChoice == 'y':
                            df = df.loc[df.index != df.columns[randomImg[0]]]  # row
                            del df[df.columns[randomImg[0]]]  # column

                            distanceMatrix = df.values
                            break

                        try:
                            df = df.loc[df.index != df.columns[randomImg[0]]]
                            del df[df.columns[randomImg[0]]]  # column

                            df = df.loc[df.index != df.columns[randomImg[1]]]
                            del df[df.columns[randomImg[1]]]  # column

                            df = df.loc[df.index != df.columns[randomImg[2]]]
                            del df[df.columns[randomImg[2]]]  # column

                            distanceMatrix = df.values
                        except Exception as e:
                            print(str(e))
                            print(df)
                            print(randomImg)
                            print(df.shape)


                        break

    distanceMatrix = df.values

    print(objectMembership)
    print(df.columns)
    print({x:y for x,y in zip(df.columns, objectMembership)})


hierarchicalClustering(distanceMatrix, 5, 20, 400)
